/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author ankit
 */
@WebService(serviceName = "INRtoUSD")
public class INRtoUSD {

    /**
     * Web service operation
     */
    @WebMethod(operationName = "operation")
    public String operation(@WebParam(name = "a") double a) {
//TODO write your implementation code here: 
        return "rupees in to" + a + "Dollor" + (a / 88.64);
    }

    /**
     * This is a sample web service operation
     */
}
