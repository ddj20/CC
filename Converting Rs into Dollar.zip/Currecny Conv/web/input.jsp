<%-- 
    Document   : input
    Created on : 31 Jan, 2026, 5:51:29 PM
    Author     : ankit
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <form action="output.jsp"> 
            <pre> 
Enter the Currency in rupees : <input type="text" name="t1"> 
<input type="submit"><input type="rest"> 
</form> 
    </body>
</html>
