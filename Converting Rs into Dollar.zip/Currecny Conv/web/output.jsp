<%-- 
    Document   : output
    Created on : 31 Jan, 2026, 5:54:59 PM
    Author     : ankit
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <% 
    try { 
        Client.INRtoUSD_Service service = new Client.INRtoUSD_Service(); 
        Client.INRtoUSD port = service.getINRtoUSDPort(); 
        // TODO initialize WS operation arguments here 
        double a = Double.parseDouble(request.getParameter("t1")); 
        // TODO process result here 
        java.lang.String result = port.operation(a); 
        out.println("Result  "+result); 
    } catch (Exception ex) { 
        // TODO handle custom exceptions here 
    } 
%> 
    </body>
</html>
