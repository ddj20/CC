package server;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.xml.ws.soap.MTOM;
import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import java.io.*;

@WebService(serviceName = "FileService")
@MTOM
public class FileService {

    private static final String UPLOAD_PATH =
            "C:\\Users\\shovi\\Downloads\\upload\\";

    // Upload File
    @WebMethod(operationName = "uploadFile")
    public String uploadFile(
            @WebParam(name = "file") DataHandler file,
            @WebParam(name = "fileName") String fileName) {

        try {

            File folder = new File(UPLOAD_PATH);
            if (!folder.exists()) {
                folder.mkdirs();
            }

            InputStream input = file.getInputStream();
            File outputFile = new File(UPLOAD_PATH + fileName);
            FileOutputStream output = new FileOutputStream(outputFile);

            byte[] buffer = new byte[4096];
            int bytesRead;

            while ((bytesRead = input.read(buffer)) != -1) {
                output.write(buffer, 0, bytesRead);
            }

            output.close();
            input.close();

            return "File Uploaded Successfully";

        } catch (Exception e) {
            return "Error: " + e.getMessage();
        }
    }

    // Download File
    @WebMethod(operationName = "downloadFile")
    public DataHandler downloadFile(
            @WebParam(name = "fileName") String fileName) {

        try {

            File file = new File(UPLOAD_PATH + fileName);

            if (!file.exists()) {
                return null;
            }

            return new DataHandler(new FileDataSource(file));

        } catch (Exception e) {
            return null;
        }
    }
}