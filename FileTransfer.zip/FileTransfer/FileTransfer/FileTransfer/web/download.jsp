<%-- 
    Document   : download
    Created on : 22 Feb, 2026, 9:10:01 PM
    Author     : Shovin
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <form action="downloadResult.jsp" method="get">
   Enter File Name:
   <input type="text" name="fname">
   <input type="submit" value="Download">
</form>

    </body>
</html>
