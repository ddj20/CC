<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="client.*"%>
<%@page import="java.io.*"%>

<!DOCTYPE html>
<html>
<head>
    <title>Download Result</title>
</head>
<body>

<%
try {

    String fileName = request.getParameter("fname");

    FileService_Service service = new FileService_Service();
    FileService port = service.getFileServicePort();

    byte[] fileData = port.downloadFile(fileName);

    if (fileData == null) {
        out.println("File not found!");
        return;
    }

    response.reset();
    response.setHeader("Content-Disposition",
            "attachment; filename=\"" + fileName + "\"");
    response.setContentType("application/octet-stream");

    OutputStream os = response.getOutputStream();
    os.write(fileData);
    os.flush();
    os.close();

} catch (Exception e) {
    out.println("Download Error: " + e.getMessage());
}
%>

</body>
</html>