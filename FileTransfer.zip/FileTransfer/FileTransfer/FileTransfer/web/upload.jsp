<%-- 
    Document   : upload
    Created on : 22 Feb, 2026, 9:07:21 PM
    Author     : Shovin
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
       <form action="uploadResult.jsp" method="post" enctype="multipart/form-data">
   Select File:
   <input type="file" name="file">
   <input type="submit" value="Upload">
</form>

    </body>
</html>
