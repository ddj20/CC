<%@page import="java.io.*,javax.servlet.http.Part"%>
<%@page import="client.*"%>

<%
try {

    Part part = request.getPart("file");
    String fileName = part.getSubmittedFileName();

    InputStream is = part.getInputStream();

    ByteArrayOutputStream baos = new ByteArrayOutputStream();
    byte[] buffer = new byte[4096];
    int bytesRead;

    while ((bytesRead = is.read(buffer)) != -1) {
        baos.write(buffer, 0, bytesRead);
    }

    byte[] fileBytes = baos.toByteArray();

    FileService_Service service = new FileService_Service();
    FileService port = service.getFileServicePort();

    String result = port.uploadFile(fileBytes, fileName);

    out.println("<h3>" + result + "</h3>");

} catch (Exception e) {
    out.println("Upload Error: " + e.getMessage());
}
%>