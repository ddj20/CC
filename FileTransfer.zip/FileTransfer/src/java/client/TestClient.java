package client;

import java.io.FileOutputStream;

public class TestClient {

    public static void main(String[] args) {

        try {

            FileService_Service service =
                    new FileService_Service();
            FileService port =
                    service.getFileServicePort();

            // Download file from server
            byte[] data = port.downloadFile("error.jpeg");

            if (data == null) {
                System.out.println("File not found on server");
                return;
            }

            // Save locally
           FileOutputStream fos =
new FileOutputStream("C:\\Users\\Muthu Krishnan\\Downloads\\download_test.jpeg");
            fos.write(data);
            fos.close();

            System.out.println("File downloaded successfully!");

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}