/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package playerClient;

import playerentities.Player;
import playerentities.Team;

public class CreatePlayerMain {

    public static void main(String[] args) {
        CreateClient client = new CreateClient();
        try {
            Player p = new Player();
            p.setId(30);
            p.setFirstname("Harry");
            p.setLastname("Potter");
            p.setJerseynumber(60);
            p.setLastspokenwords("Thanks to my fans");

            // 🔹 Set the team relation
            Team t = new Team();
            t.setTeamid(1);      // TEAMID that already exists in TEAM table
            p.setTeamid(t);      // attach team object to player

            // send to REST service
            client.create_XML(p);   // or create_JSON(p);
            System.out.println("Player created successfully!");
        } finally {
            client.close();
        }
    }
}

