/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package playerClient;

public class DeletePlayerMain {
    public static void main(String[] args) {
        CreateClient client = new CreateClient();
        String id = "30";   // player id to delete

        try {
            client.remove(id);
            System.out.println("Player with id " + id + " deleted successfully!");
        } finally {
            client.close();
        }
    }
}

