/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package playerClient;

import playerentities.Player;

public class ReadPlayersMain {
    public static void main(String[] args) {
        CreateClient client = new CreateClient();
        try {
            // findAll_XML returns list; we map it to an array
            Player[] players = client.findAll_XML(Player[].class);

            System.out.println("Retrieving and displaying player details:");
            if (players != null) {
                for (Player p : players) {
                    System.out.println("Id: " + p.getId());
                    System.out.println("First Name: " + p.getFirstname());
                    System.out.println("Last Name: " + p.getLastname());
                    System.out.println("Jersey No: " + p.getJerseynumber());
                    System.out.println("Last Spoken Words: " + p.getLastspokenwords());
                    System.out.println("Team Id: " + p.getTeamid());
                    System.out.println("---------------------------");
                }
            } else {
                System.out.println("No players found.");
            }
        } finally {
            client.close();
        }
    }
}

