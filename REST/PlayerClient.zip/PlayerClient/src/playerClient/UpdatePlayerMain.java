/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package playerClient;

import playerentities.Player;

public class UpdatePlayerMain {
    public static void main(String[] args) {
        CreateClient client = new CreateClient();
        String id = "30";   // player id you want to update

        try {
            // 1. Get existing player
            Player p = client.find_XML(Player.class, id);

            if (p == null) {
                System.out.println("Player with id " + id + " not found.");
                return;
            }

            System.out.println("Before update:");
            System.out.println("First Name: " + p.getFirstname());
            System.out.println("Jersey No: " + p.getJerseynumber());
            System.out.println("Last Spoken Words: " + p.getLastspokenwords());

            // 2. Modify fields
            p.setJerseynumber(100);
            p.setLastspokenwords("I will be retiring soon");

            // 3. Send update back to server
            client.edit_XML(p, id);   // or edit_JSON(p, id);

            System.out.println("\nPlayer updated successfully!");
        } finally {
            client.close();
        }
    }
}

