/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Muthu Krishnan
 */
@WebService(serviceName = "Prime")
public class Prime {

    /**
     * Web service operation
     */
    @WebMethod(operationName = "checkPrime")
public String checkPrime(@WebParam(name = "n") int n) {

    int i,count=0;

    for(i=1;i<=n;i++)
    {
        if(n%i==0)
            count++;
    }

    if(count==2)
        return "Prime Number";
    else
        return "Not Prime Number";
}
    }

    /**
     * This is a sample web service operation
     */
  
    

