<%-- 
    Document   : input
    Created on : 10 Mar, 2026, 12:12:19 AM
    Author     : Muthu Krishnan
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        
<form action="output.jsp">

Enter Number:
<input type="text" name="t1">

<br><br>

<input type="submit" value="Check">

</form>

    </body>
</html>
