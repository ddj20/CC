<%-- 
    Document   : output
    Created on : 10 Mar, 2026, 12:14:19 AM
    Author     : Muthu Krishnan
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <%
try{

int num = Integer.parseInt(request.getParameter("t1"));

client.Prime_Service service = new client.Prime_Service();
client.Prime port = service.getPrimePort();

String result = port.checkPrime(num);

out.println("Result : " + result);

}

catch(Exception e){
out.println(e);
}
%>
    </body>
</html>
