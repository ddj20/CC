/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Muthu Krishnan
 */
@WebService(serviceName = "Temperature")
public class Temperature {

    /**
     * Web service operation
     */
   
    @WebMethod(operationName = "operation")
    public double operation(@WebParam(name = "f") double f) {
        
        return (f - 32) * 5 / 9;
        
    }
}

    /**
     * This is a sample web service operation
     */
   
    

