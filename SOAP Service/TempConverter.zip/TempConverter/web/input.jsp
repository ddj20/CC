<%-- 
    Document   : input
    Created on : 9 Mar, 2026, 11:56:22 PM
    Author     : Muthu Krishnan
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <form action="output.jsp" method="post">

Enter Temperature in Fahrenheit:
<input type="text" name="t1" required>

<br><br>

<input type="submit" value="Convert">

</form>
    </body>
</html>
