<%-- 
    Document   : output
    Created on : 10 Mar, 2026, 12:01:07 AM
    Author     : Muthu Krishnan
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
       <%
try {

    client.Temperature_Service service = new client.Temperature_Service();
    client.Temperature port = service.getTemperaturePort();

    double f = Double.parseDouble(request.getParameter("t1"));

    double result = port.operation(f);

    out.println("Celsius Value : " + result);

} catch(Exception e) {
    out.println(e);
}
%>
    </body>
</html>
