/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.xml.ws.RequestWrapper;
import javax.xml.ws.ResponseWrapper;

/**
 *
 * @author ankit
 */
@WebService(serviceName = "add")
public class add {

    /**
     * This is a sample web service operation
     */
   

    /**
     * Web service operation
     */
   @WebMethod(operationName = "add")
public String add(@WebParam(name = "a") float a,
                  @WebParam(name = "b") float b) {
    float sum = a + b;
    return "Addition is : " + sum;
}

}
