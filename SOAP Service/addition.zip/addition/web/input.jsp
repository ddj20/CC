<%-- 
    Document   : input
    Created on : 5 Mar, 2026, 12:50:41 PM
    Author     : ankit
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <form action ="output.jsp" method="get">
            <pre>
                Enter First Value:<input type="text" name="v1">
                Enter Second Value:<input type="text" name="v2">
                <input type="submit" value="Submit">
                <input type="reset" value="Reset">
            </pre>
        </form>
    
    
    </body>
</html>
