<%-- 
    Document   : output
    Created on : 5 Mar, 2026, 12:50:54 PM
    Author     : ankit
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>

<%@page import="Clinet.Add_Service"%>
<%@page import="Clinet.Add"%>

<!DOCTYPE html>
<html>
<head>
    <title>Output</title>
</head>
<body>
<%
try {
    float a = Float.parseFloat(request.getParameter("v1"));
    float b = Float.parseFloat(request.getParameter("v2"));

    Clinet.Add_Service service = new Clinet.Add_Service();
    Clinet.Add port = service.getAddPort();

    String result = port.add(a, b);

    out.println("Result = " + result);

} catch (Exception ex) {
    out.println("Error : " + ex.getMessage());
}
%>
</body>
</html>


